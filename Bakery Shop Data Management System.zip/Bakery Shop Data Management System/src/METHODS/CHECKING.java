 
package METHODS;
  
import java.sql.DriverManager;
import java.sql.SQLException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class CHECKING {
    
    public class DatabaseConnection {
    public static final String URL = "jdbc:mysql://localhost:3306/bakery_management";
    public static final String USERNAME = "root"; // Change if your MySQL username is different
    public static final String PASSWORD = ""; // Add your MySQL password here
    
    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Database connection error: " + e.getMessage());
            return null;
        }
    }
    
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println("Error closing connection: " + e.getMessage());
            }
        }
    }
    
     
    public boolean check_invoice(int invoice){
        boolean check_invoice=false;
        
        int id = invoice;
        
         try (Connection conn = DatabaseConnection.getConnection()) {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, id); 

        ResultSet rs = stmt.executeQuery();

        if (rs.next()) { 
            check_invoice=true;
        }

    } catch (Exception ex) {
        ex.printStackTrace(); 
    } 
        
        return check_invoice;
    }
    
    }



}