/*
 * Customer Order History - Simple 4 Columns
 */

import date.datechooser.DateChooser;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class customer extends javax.swing.JFrame {

    private DefaultTableModel orderHistoryTableModel;
    private int selectedRow = -1;
    private DateChooser datechooser = new DateChooser(); 
    
    
    public customer() {
        initComponents();
        setupOrderHistoryTable();
        loadOrderHistory();
        setupTableClickListener(); 
        
        datechooser.setDateFormat(new SimpleDateFormat("yyyy-MM-dd")); 
        datechooser.setTextField(filter_date);
    }

    // Setup the order history table with your 4 columns
    private void setupOrderHistoryTable() {
        orderHistoryTableModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        
        // Your 4 columns only
        String[] columns = {"Customer ID", "Total", "Date", "Product Name", "Invoice ID"};
        orderHistoryTableModel.setColumnIdentifiers(columns);
        jTable1.setModel(orderHistoryTableModel);
        
        // Set column widths
        jTable1.getColumnModel().getColumn(0).setPreferredWidth(120); // Customer ID
        jTable1.getColumnModel().getColumn(1).setPreferredWidth(150); // Total
        jTable1.getColumnModel().getColumn(2).setPreferredWidth(200); // Date
        jTable1.getColumnModel().getColumn(3).setPreferredWidth(250); // Product Name
        jTable1.getColumnModel().getColumn(4).setPreferredWidth(250); // Invoice
    }

    // Setup table click listener for row selection
    private void setupTableClickListener() {
        jTable1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                selectedRow = jTable1.getSelectedRow();
                if (selectedRow >= 0) {
                    System.out.println("Selected row: " + selectedRow);
                }
            }
        });
    }

    // Load all order history from your existing database
    private void loadOrderHistory() {
        orderHistoryTableModel.setRowCount(0); // Clear existing data
        
        // Simple query using existing columns from transactions table
        String query = "SELECT id, total_price, transaction_date, product_name, transaction_number FROM transactions ORDER BY transaction_date DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            
            if (conn == null) {
                JOptionPane.showMessageDialog(this, "Database connection failed!");
                return;
            }
            
            int rowCount = 0;
            while (rs.next()) {
                double totalPrice = rs.getDouble("total_price");
                
                Object[] row = {
                    rs.getInt("id"),                                    // Customer ID
                    String.format("₱%.2f", totalPrice),                // Total
                    rs.getTimestamp("transaction_date"),               // Date
                    rs.getString("product_name"),
                    rs.getString("transaction_number")                       // Product Name
                };
                orderHistoryTableModel.addRow(row);
                rowCount++;
            }
            
            System.out.println("Loaded " + rowCount + " rows");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading order history: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // View transaction details (for button 3)
    private void viewPaymentDetails() {
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a transaction to view details!");
            return;
        }

        try {
            int customerId = (Integer) orderHistoryTableModel.getValueAt(selectedRow, 0);
            String total = orderHistoryTableModel.getValueAt(selectedRow, 1).toString();
            String date = orderHistoryTableModel.getValueAt(selectedRow, 2).toString();
            String productName = orderHistoryTableModel.getValueAt(selectedRow, 3).toString();
            
            String details = String.format(
                "TRANSACTION DETAILS\n" +
                "==================\n" +
                "Customer ID: %d\n" +
                "Total Amount: %s\n" +
                "Transaction Date: %s\n" +
                "Product Name: %s",
                customerId, total, date, productName
            );
            
            JOptionPane.showMessageDialog(this, details, "Transaction Details", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error viewing details: " + e.getMessage());
        }
    }

    // Delete selected order (for button 4)
    private void deleteSelectedOrder() {
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a transaction to delete!");
            return;
        }

        try {
            int customerId = (Integer) orderHistoryTableModel.getValueAt(selectedRow, 0);
            String total = orderHistoryTableModel.getValueAt(selectedRow, 1).toString();
            String productName = orderHistoryTableModel.getValueAt(selectedRow, 3).toString();
            
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this transaction?\n\n" +
                "Customer ID: " + customerId + "\n" +
                "Product: " + productName + "\n" +
                "Total: " + total,
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
            
            if (confirm != JOptionPane.YES_OPTION) return;

            String deleteQuery = "DELETE FROM transactions WHERE id = ? LIMIT 1";
            
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(deleteQuery)) {
                
                if (conn == null) {
                    JOptionPane.showMessageDialog(this, "Database connection failed!");
                    return;
                }
                
                pstmt.setInt(1, customerId);
                int result = pstmt.executeUpdate();
                
                if (result > 0) {
                    JOptionPane.showMessageDialog(this, "Transaction deleted successfully!");
                    loadOrderHistory();
                    selectedRow = -1;
                    jTable1.clearSelection();
                } else {
                    JOptionPane.showMessageDialog(this, "Transaction not found!");
                }
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error deleting transaction: " + e.getMessage());
                e.printStackTrace();
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Refresh order history (for button 5)
    private void refreshOrderHistory() {
        loadOrderHistory();
        selectedRow = -1;
        jTable1.clearSelection();
        JOptionPane.showMessageDialog(this, "Order history refreshed!");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel1 = new keeptoo.KGradientPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        filter_date = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Customer");
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel1.setkEndColor(new java.awt.Color(102, 0, 0));
        kGradientPanel1.setkStartColor(new java.awt.Color(51, 0, 51));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Customer ID", "Total", "Date", "Product Name", "Invoive ID"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        kGradientPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 1210, 730));

        jLabel1.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-customer-25.png"))); // NOI18N
        jLabel1.setText("Customers");
        kGradientPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        filter_date.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        filter_date.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        filter_date.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                filter_dateFocusLost(evt);
            }
        });
        filter_date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                filter_dateMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                filter_dateMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                filter_dateMouseReleased(evt);
            }
        });
        filter_date.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                filter_dateInputMethodTextChanged(evt);
            }
        });
        filter_date.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filter_dateActionPerformed(evt);
            }
        });
        filter_date.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                filter_dateKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                filter_dateKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                filter_dateKeyTyped(evt);
            }
        });
        kGradientPanel1.add(filter_date, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 10, 150, 30));

        jButton1.setText("CLEAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 10, -1, 30));

        jButton2.setText("SEARCH");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 10, 80, 30));

        getContentPane().add(kGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1230, 790));

        pack();
    }// </editor-fold>//GEN-END:initComponents

     public void search(JTable table, JTextField searchField) {
        DefaultTableModel studentsTableModel = (DefaultTableModel) table.getModel(); // Get table model
        TableRowSorter<DefaultTableModel> rowSorter = new TableRowSorter<>(studentsTableModel); // Create row sorter
        table.setRowSorter(rowSorter);  // Set the row sorter on the table
         
            String searchText = searchField.getText().trim(); // Get the text from the search field
            if (searchText.isEmpty()) {
                rowSorter.setRowFilter(null); // Show all rows if search field is empty
            } else {
                try {
                    // Apply a regex filter for case-insensitive matching
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
                } catch (java.util.regex.PatternSyntaxException ex) {
                    // Handle invalid regex patterns gracefully
                    System.err.println("Invalid regex pattern: " + ex.getMessage());
                    rowSorter.setRowFilter(null); // Show all rows if regex is invalid
                }
            }
        
    } 
    
    
    private void filter_dateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filter_dateActionPerformed
       
    }//GEN-LAST:event_filter_dateActionPerformed

    private void filter_dateKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_filter_dateKeyReleased
       
    }//GEN-LAST:event_filter_dateKeyReleased

    private void filter_dateMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filter_dateMouseReleased
       
    }//GEN-LAST:event_filter_dateMouseReleased

    private void filter_dateMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filter_dateMousePressed
         
    }//GEN-LAST:event_filter_dateMousePressed

    private void filter_dateInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_filter_dateInputMethodTextChanged
        
    }//GEN-LAST:event_filter_dateInputMethodTextChanged

    private void filter_dateKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_filter_dateKeyTyped
       
    }//GEN-LAST:event_filter_dateKeyTyped

    private void filter_dateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filter_dateMouseClicked
         
    }//GEN-LAST:event_filter_dateMouseClicked

    private void filter_dateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_filter_dateKeyPressed
         
    }//GEN-LAST:event_filter_dateKeyPressed

    private void filter_dateFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_filter_dateFocusLost
          
    }//GEN-LAST:event_filter_dateFocusLost

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        search(jTable1,filter_date);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        filter_date.setText("");
         search(jTable1,filter_date);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    
    // Button action methods (simplified)
                 

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        refreshOrderHistory();
    }                   
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new customer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField filter_date;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private keeptoo.KGradientPanel kGradientPanel1;
    // End of variables declaration//GEN-END:variables
}
