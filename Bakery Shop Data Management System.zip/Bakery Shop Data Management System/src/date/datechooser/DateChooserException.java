package date.datechooser;

public class DateChooserException extends RuntimeException {

    public DateChooserException(String errorMessage) {
        super(errorMessage);
    }
}
