package date.datechooser;

import java.util.Date;

public interface DateSelectable {

    public boolean isDateSelectable(Date date);
}
