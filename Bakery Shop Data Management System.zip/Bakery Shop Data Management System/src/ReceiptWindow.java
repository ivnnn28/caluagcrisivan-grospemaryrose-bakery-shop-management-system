/*
 * Receipt Window for Bakery POS System
 */

import METHODS.CHECKING;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class ReceiptWindow extends JFrame {
    
    private JTextArea receiptArea;
    private JButton exitButton;
    private JButton printButton;
    
    CHECKING CK = new CHECKING();
    
    // Order item class to hold product details
    public static class OrderItem {
        private String productName;
        private int quantity;
        private double unitPrice;
        private double totalPrice;
        
        public OrderItem(String productName, int quantity, double unitPrice) {
            this.productName = productName;
            this.quantity = quantity;
            this.unitPrice = unitPrice;
            this.totalPrice = quantity * unitPrice;
        }
        
        // Getters
        public String getProductName() { return productName; }
        public int getQuantity() { return quantity; }
        public double getUnitPrice() { return unitPrice; }
        public double getTotalPrice() { return totalPrice; }
    }
    
    public ReceiptWindow(List<OrderItem> orderItems, double amountPaid, int transactionNumber) {
        initComponents();
        generateReceipt(orderItems, amountPaid, transactionNumber);
        setupEventListeners();
    }
    
    private void initComponents() {
        setTitle("Customer Receipt - Sweet Bakery");
        setSize(500, 700);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBackground(new java.awt.Color(255, 255, 255));
        
        // Title label
        JLabel titleLabel = new JLabel("CUSTOMER RECEIPT", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(new java.awt.Color(0, 102, 102));
        titleLabel.setBounds(50, 20, 400, 30);
        mainPanel.add(titleLabel);
        
        // Receipt text area
        receiptArea = new JTextArea();
        receiptArea.setFont(new Font("Courier New", Font.PLAIN, 12));
        receiptArea.setEditable(false);
        receiptArea.setBackground(new java.awt.Color(255, 255, 255));
        receiptArea.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        
        JScrollPane scrollPane = new JScrollPane(receiptArea);
        scrollPane.setBounds(30, 60, 440, 500);
        mainPanel.add(scrollPane);
        
        // Print button
        printButton = new JButton("Print Receipt");
        printButton.setBounds(50, 580, 150, 35);
        printButton.setBackground(new java.awt.Color(76, 175, 80));
        printButton.setForeground(java.awt.Color.WHITE);
        printButton.setFont(new Font("Arial", Font.BOLD, 12));
        mainPanel.add(printButton);
        
        // Exit button
        exitButton = new JButton("Exit");
        exitButton.setBounds(300, 580, 150, 35);
        exitButton.setBackground(new java.awt.Color(244, 67, 54));
        exitButton.setForeground(java.awt.Color.WHITE);
        exitButton.setFont(new Font("Arial", Font.BOLD, 12));
        mainPanel.add(exitButton);
        
        add(mainPanel);
    }
    
    private void generateReceipt(List<OrderItem> orderItems, double amountPaid, int transactionNumber) {
        StringBuilder receipt = new StringBuilder();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentDate = dateFormat.format(new Date());
       
        
        
        // Header
        receipt.append("================================================\n");
        receipt.append("                BAKERY NATIN                  \n");
        receipt.append("              Customer Receipt                  \n");
        receipt.append("================================================\n");
        receipt.append("Date: ").append(currentDate).append("\n");
        receipt.append("Receipt #: ").append(String.format("%06d", transactionNumber)).append("\n");
        receipt.append("Cashier: Admin\n");
        receipt.append("================================================\n\n");
        
        // Column headers
        receipt.append(String.format("%-20s %3s %8s %10s\n", "ITEM", "QTY", "PRICE", "TOTAL"));
        receipt.append("------------------------------------------------\n");
        
        // Order items - This shows what the customer ordered
        double grandTotal = 0;
        for (OrderItem item : orderItems) {
            receipt.append(String.format("%-20s %3d ₱%7.2f ₱%9.2f\n", 
                truncateString(item.getProductName(), 20),
                item.getQuantity(),
                item.getUnitPrice(),
                item.getTotalPrice()));
            grandTotal += item.getTotalPrice();
        }
        
        receipt.append("------------------------------------------------\n");
        
        // Totals
        receipt.append(String.format("%-32s ₱%9.2f\n", "SUBTOTAL:", grandTotal));
        receipt.append(String.format("%-32s ₱%9.2f\n", "TAX (0%):", 0.00));
        receipt.append("================================================\n");
        receipt.append(String.format("%-32s ₱%9.2f\n", "TOTAL AMOUNT:", grandTotal));
        receipt.append(String.format("%-32s ₱%9.2f\n", "AMOUNT PAID:", amountPaid));
        
        // Calculate change
        double change = amountPaid - grandTotal;
        receipt.append(String.format("%-32s ₱%9.2f\n", "CHANGE:", change));
        receipt.append("================================================\n\n");
        
        // Footer
        receipt.append("           Thank you for your purchase!         \n");
        receipt.append("              Please come again!                \n");
        receipt.append("================================================\n");
        
        // Payment status
        if (change >= 0) {
            receipt.append("                 PAID IN FULL                  \n");
        } else {
            receipt.append("              BALANCE DUE: ₱").append(String.format("%.2f", Math.abs(change))).append("\n");
        }
        
        receipt.append("================================================\n");
        receipt.append("         This receipt is proof of purchase      \n");
        receipt.append("================================================\n");
        
        receiptArea.setText(receipt.toString());
    }
    
    private void setupEventListeners() {
        // Exit button action
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int confirm = JOptionPane.showConfirmDialog(
                    ReceiptWindow.this,
                    "Are you sure you want to close the receipt?",
                    "Confirm Exit",
                    JOptionPane.YES_NO_OPTION
                );
                
                if (confirm == JOptionPane.YES_OPTION) {
                    dispose();
                }
            }
        });
        
        // Print button action
        printButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                printReceipt();
            }
        });
    }
    
    private void printReceipt() {
        try {
            boolean printed = receiptArea.print();
            if (printed) {
                JOptionPane.showMessageDialog(this, 
                    "Receipt sent to printer successfully!", 
                    "Print Success", 
                    JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error printing receipt: " + e.getMessage(), 
                "Print Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private String truncateString(String str, int maxLength) {
        if (str.length() <= maxLength) {
            return str;
        }
        return str.substring(0, maxLength - 3) + "...";
    }
    
    // Static method to show receipt from menu.java
    public static void showReceipt(List<OrderItem> orderItems, double amountPaid, int transactionNumber) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ReceiptWindow receiptWindow = new ReceiptWindow(orderItems, amountPaid, transactionNumber);
                    receiptWindow.setVisible(true);
                    receiptWindow.toFront();
                    receiptWindow.requestFocus();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, 
                        "Error showing receipt: " + e.getMessage(), 
                        "Receipt Error", 
                        JOptionPane.ERROR_MESSAGE);
                    e.printStackTrace();
                }
            }
        });
    }
}