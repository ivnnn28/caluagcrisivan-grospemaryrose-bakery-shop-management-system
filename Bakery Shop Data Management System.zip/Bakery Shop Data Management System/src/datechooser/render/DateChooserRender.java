package datechooser.render;

import date.datechooser.DateBetween;
import date.datechooser.DateChooser;

import java.util.Date;

public interface DateChooserRender {
    String renderLabelCurrentDate(Object dateChooser, Date date);
    String renderTextFieldDate(DateChooser dateChooser, Date date);
    String renderTextFieldDateBetween(DateChooser dateChooser, DateBetween dateBetween);
    String renderDateCell(DateChooser dateChooser, Date date);
}