import date.datechooser.DateChooser;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.IllegalComponentStateException;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class dashboard extends javax.swing.JFrame {
    private inventory invenWindow = null;
    private menu menuWindow = null;
    private customer cusWindow = null;
    
    // Statistics variables
    private double totalIncome = 0.0;
    private double todayIncome = 0.0;
    private double monthlyIncome = 0.0;
    private int totalCustomers = 0;
    private Map<String, Double> monthlyIncomeData = new LinkedHashMap<>();
    private Map<String, Integer> monthlyCustomerData = new LinkedHashMap<>();
    
    // Chart panels
    private JPanel incomeChartPanel;
    private JPanel customerChartPanel;
    
    // Calendar components
    private JPanel calendarPanel;
    private JComboBox<String> monthComboBox;
    private JComboBox<Integer> yearComboBox;
    private JPanel daysPanel;
    private JButton selectedDateButton = null;
    private Calendar selectedCalendar;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    
    // Custom colors for calendar
    private final Color LIGHT_GREEN = new Color(144, 238, 144);  // Light green for days with data
    private final Color LIGHT_YELLOW = new Color(255, 255, 224); // Light yellow for today
    private final Color LIGHT_GRAY = new Color(240, 240, 240);   // Light gray for calendar header
    
    // Month names for charts
    private final String[] MONTH_NAMES = {
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    };
    
    // Auto-refresh timer
    private Timer refreshTimer;
    private DateChooser datechooser = new DateChooser(); 
    public dashboard() {
        initComponents();
        initializeCalendar();
        initializeStatistics();
        
        createChartPanels();
        startAutoRefresh();
        
        
        datechooser.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));  
        
    }

    // Initialize calendar components
    private void initializeCalendar() {
        selectedCalendar = Calendar.getInstance();
        createCalendarPanel();
        updateCalendarDisplay();
    }

    // Create calendar panel
    private void createCalendarPanel() {
        calendarPanel = new JPanel(new BorderLayout());
        calendarPanel.setBorder(BorderFactory.createTitledBorder("Select Date for Analytics"));
        calendarPanel.setBackground(Color.WHITE);
        
        // Top panel with month/year selectors
        JPanel topPanel = new JPanel();
        topPanel.setBackground(Color.WHITE);
        
        // Month selector
        String[] months = {"January", "February", "March", "April", "May", "June",
                          "July", "August", "September", "October", "November", "December"};
        monthComboBox = new JComboBox<>(months);
        monthComboBox.setSelectedIndex(selectedCalendar.get(Calendar.MONTH));
        monthComboBox.addActionListener(e -> updateCalendarDisplay());
        
        // Year selector
        Integer[] years = new Integer[10];
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int i = 0; i < 10; i++) {
            years[i] = currentYear - 5 + i;
        }
        yearComboBox = new JComboBox<>(years);
        yearComboBox.setSelectedItem(selectedCalendar.get(Calendar.YEAR));
        yearComboBox.addActionListener(e -> {
            updateCalendarDisplay();
            // Update charts when year changes
            int selectedYear = (Integer) yearComboBox.getSelectedItem();
            calculateYearlyMonthlyData(selectedYear);
            if (incomeChartPanel != null) incomeChartPanel.repaint();
            if (customerChartPanel != null) customerChartPanel.repaint();
        });
        
        // Today button
        JButton todayButton = new JButton("Today");
        todayButton.addActionListener(e -> {
            selectedCalendar = Calendar.getInstance();
            monthComboBox.setSelectedIndex(selectedCalendar.get(Calendar.MONTH));
            yearComboBox.setSelectedItem(selectedCalendar.get(Calendar.YEAR));
            updateCalendarDisplay();
            filterDataByDate();
            // Update charts for current year
            calculateYearlyMonthlyData(selectedCalendar.get(Calendar.YEAR));
            if (incomeChartPanel != null) incomeChartPanel.repaint();
            if (customerChartPanel != null) customerChartPanel.repaint();
        });
        
        topPanel.add(new JLabel("Month: "));
        topPanel.add(monthComboBox);
        topPanel.add(new JLabel("  Year: "));
        topPanel.add(yearComboBox);
        topPanel.add(todayButton);
        
        // Days header
        JPanel headerPanel = new JPanel(new GridLayout(1, 7));
        headerPanel.setBackground(LIGHT_GRAY);
        String[] dayHeaders = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        for (String day : dayHeaders) {
            JLabel dayLabel = new JLabel(day, SwingConstants.CENTER);
            dayLabel.setFont(new Font("Arial", Font.BOLD, 12));
            dayLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            headerPanel.add(dayLabel);
        }
        
        // Days panel
        daysPanel = new JPanel(new GridLayout(6, 7));
        daysPanel.setBackground(Color.WHITE);
        
        calendarPanel.add(topPanel, BorderLayout.NORTH);
        calendarPanel.add(headerPanel, BorderLayout.CENTER);
        calendarPanel.add(daysPanel, BorderLayout.SOUTH);
        
        // Add calendar to the main panel
        jPanel1.add(calendarPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 580, 300));
    }

    // Update calendar display
    private void updateCalendarDisplay() {
        daysPanel.removeAll();
        
        int month = monthComboBox.getSelectedIndex();
        int year = (Integer) yearComboBox.getSelectedItem();
        
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, 1);
        
        int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1;
        int daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        
        // Add empty cells for days before the first day of the month
        for (int i = 0; i < firstDayOfWeek; i++) {
            daysPanel.add(new JLabel(""));
        }
        
        // Add day buttons
        for (int day = 1; day <= daysInMonth; day++) {
            JButton dayButton = new JButton(String.valueOf(day));
            dayButton.setPreferredSize(new Dimension(40, 30));
            
            // Check if this day has sales data
            cal.set(year, month, day);
            String dateStr = dateFormat.format(cal.getTime());
            if (hasDataForDate(dateStr)) {
                dayButton.setBackground(LIGHT_GREEN);
                dayButton.setToolTipText("Sales data available for " + dateStr);
            } else {
                dayButton.setBackground(Color.WHITE);
                dayButton.setToolTipText("No sales data for " + dateStr);
            }
            
            // Highlight today
            Calendar today = Calendar.getInstance();
            if (year == today.get(Calendar.YEAR) && 
                month == today.get(Calendar.MONTH) && 
                day == today.get(Calendar.DAY_OF_MONTH)) {
                dayButton.setBackground(Color.YELLOW);
                dayButton.setToolTipText("Today - " + dateStr);
            }
            
            // Add click listener
            final int selectedDay = day;
            dayButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Reset previous selection
                    if (selectedDateButton != null && selectedDateButton != dayButton) {
                        selectedDateButton.setBorder(null);
                    }
                    
                    // Highlight selected date
                    dayButton.setBorder(BorderFactory.createLineBorder(Color.RED, 3));
                    selectedDateButton = dayButton;
                    
                    // Update selected calendar
                    selectedCalendar.set(year, month, selectedDay);
                    
                    // Filter data by selected date
                    filterDataByDate();
                }
            });
            
            daysPanel.add(dayButton);
        }
        
        daysPanel.revalidate();
        daysPanel.repaint();
    }

    // Check if there's sales data for a specific date
    private boolean hasDataForDate(String dateStr) {
        String query = "SELECT COUNT(*) as count FROM transactions WHERE DATE(transaction_date) = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            if (conn == null) return false;
            
            pstmt.setString(1, dateStr);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("count") > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("Error checking data for date: " + e.getMessage());
        }
        
        return false;
    }

    // Filter data by selected date
    private void filterDataByDate() {
        String selectedDate = dateFormat.format(selectedCalendar.getTime());
        
        // Calculate statistics for selected date
        calculateDateSpecificStatistics(selectedDate);
        
        // Update labels
        updateStatisticsLabels();
        
        // Refresh charts
        if (incomeChartPanel != null) incomeChartPanel.repaint();
        if (customerChartPanel != null) customerChartPanel.repaint();
        
        // Show selected date info
        SimpleDateFormat displayFormat = new SimpleDateFormat("MMMM dd, yyyy");
        String displayDate = displayFormat.format(selectedCalendar.getTime());
        jLabel18.setText("Analytics for: " + displayDate);
    }

    // Calculate statistics for a specific date
    private void calculateDateSpecificStatistics(String selectedDate) {
        // Today's income (for selected date)
        todayIncome = 0.0;
        String todayQuery = "SELECT SUM(total_price) as today_income FROM transactions WHERE DATE(transaction_date) = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(todayQuery)) {
            
            if (conn != null) {
                pstmt.setString(1, selectedDate);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    todayIncome = rs.getDouble("today_income");
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error calculating date-specific income: " + e.getMessage());
        }
        
        // Calculate monthly data up to selected date
        Calendar cal = Calendar.getInstance();
        cal.setTime(selectedCalendar.getTime());
        int selectedMonth = cal.get(Calendar.MONTH) + 1;
        int selectedYear = cal.get(Calendar.YEAR);
        
        // Monthly income up to selected date
        monthlyIncome = 0.0;
        String monthlyQuery = "SELECT SUM(total_price) as monthly_income FROM transactions WHERE MONTH(transaction_date) = ? AND YEAR(transaction_date) = ? AND DATE(transaction_date) <= ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(monthlyQuery)) {
            
            if (conn != null) {
                pstmt.setInt(1, selectedMonth);
                pstmt.setInt(2, selectedYear);
                pstmt.setString(3, selectedDate);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    monthlyIncome = rs.getDouble("monthly_income");
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error calculating monthly income: " + e.getMessage());
        }
        
        // Keep total income and customers as overall statistics
        calculateTotalIncome();
        calculateTotalCustomers();
        
        // Update charts for the selected year
        calculateYearlyMonthlyData(selectedYear);
    }

    // Initialize and calculate all statistics
    private void initializeStatistics() {
        calculateTotalIncome();
        calculateTodayIncome();
        calculateMonthlyIncome();
        calculateTotalCustomers();
        
        // Calculate yearly data for current year
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        calculateYearlyMonthlyData(currentYear);
        
        updateStatisticsLabels();
    }

    // Calculate total income from all transactions
    private void calculateTotalIncome() {
        totalIncome = 0.0;
        String query = "SELECT SUM(total_price) as total_income FROM transactions";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            
            if (conn != null && rs.next()) {
                totalIncome = rs.getDouble("total_income");
            }
            
        } catch (SQLException e) {
            System.err.println("Error calculating total income: " + e.getMessage());
        }
    }

    // Calculate today's income
    private void calculateTodayIncome() {
        todayIncome = 0.0;
        String query = "SELECT SUM(total_price) as today_income FROM transactions WHERE DATE(transaction_date) = CURDATE()";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            
            if (conn != null && rs.next()) {
                todayIncome = rs.getDouble("today_income");
            }
            
        } catch (SQLException e) {
            System.err.println("Error calculating today's income: " + e.getMessage());
        }
    }

    // Calculate current month's income
    private void calculateMonthlyIncome() {
        monthlyIncome = 0.0;
        String query = "SELECT SUM(total_price) as monthly_income FROM transactions WHERE MONTH(transaction_date) = MONTH(CURDATE()) AND YEAR(transaction_date) = YEAR(CURDATE())";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            
            if (conn != null && rs.next()) {
                monthlyIncome = rs.getDouble("monthly_income");
            }
            
        } catch (SQLException e) {
            System.err.println("Error calculating monthly income: " + e.getMessage());
        }
    }

    // Calculate total number of unique customers
    private void calculateTotalCustomers() {
        totalCustomers = 0;
        String query = "SELECT COUNT(DISTINCT id) as customer_count FROM transactions";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            
            if (conn != null && rs.next()) {
                totalCustomers = rs.getInt("customer_count");
            }
            
        } catch (SQLException e) {
            System.err.println("Error calculating total customers: " + e.getMessage());
        }
    }

    // Calculate yearly monthly data for charts (January to December for specified year)
    private void calculateYearlyMonthlyData(int year) {
        monthlyIncomeData.clear();
        monthlyCustomerData.clear();
        
        // Initialize all months with zero values
        for (int month = 1; month <= 12; month++) {
            String monthKey = String.format("%02d", month);
            monthlyIncomeData.put(monthKey, 0.0);
            monthlyCustomerData.put(monthKey, 0);
        }
        
        String query = """
            SELECT 
                MONTH(transaction_date) as month,
                SUM(total_price) as monthly_income,
                COUNT(DISTINCT id) as monthly_customers
            FROM transactions 
            WHERE YEAR(transaction_date) = ?
            GROUP BY MONTH(transaction_date)
            ORDER BY month
        """;
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            if (conn == null) return;
            
            pstmt.setInt(1, year);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                int month = rs.getInt("month");
                double income = rs.getDouble("monthly_income");
                int customers = rs.getInt("monthly_customers");
                
                String monthKey = String.format("%02d", month);
                monthlyIncomeData.put(monthKey, income);
                monthlyCustomerData.put(monthKey, customers);
            }
            
        } catch (SQLException e) {
            System.err.println("Error calculating yearly monthly data: " + e.getMessage());
        }
    }

    // Update all statistics labels
    private void updateStatisticsLabels() {
        jLabel22.setText(String.valueOf(totalCustomers)); // Number of Customers
        jLabel24.setText(String.format("₱%.2f", todayIncome)); // Today's Income (or selected date)
        jLabel26.setText(String.format("₱%.2f", monthlyIncome)); // Monthly Income
        jLabel20.setText(String.format("₱%.2f", totalIncome)); // Total Income
    }

    // Create chart panels
    private void createChartPanels() {
        // Income chart panel
        incomeChartPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawIncomeChart(g);
            }
        };
        incomeChartPanel.setBackground(Color.WHITE);
        
        // Get selected year for chart title
        int selectedYear = (Integer) yearComboBox.getSelectedItem();
        incomeChartPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Monthly Income Trend - " + selectedYear));
        
        // Customer chart panel
        customerChartPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawCustomerChart(g);
            }
        };
        customerChartPanel.setBackground(Color.WHITE);
        customerChartPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Monthly Customer Count - " + selectedYear));
        
        // Add panels to the dashboard
        jPanel5.removeAll();
        jPanel5.setLayout(new BorderLayout());
        jPanel5.add(incomeChartPanel, BorderLayout.CENTER);
        
        jPanel4.removeAll();
        jPanel4.setLayout(new BorderLayout());
        jPanel4.add(customerChartPanel, BorderLayout.CENTER);
        
        jPanel5.revalidate();
        jPanel5.repaint();
        jPanel4.revalidate();
        jPanel4.repaint();
    }

    // Draw income line chart
    private void drawIncomeChart(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        int width = incomeChartPanel.getWidth() - 80;
        int height = incomeChartPanel.getHeight() - 80;
        int startX = 40;
        int startY = 40;
        
        if (width <= 0 || height <= 0) {
            g2d.setColor(Color.GRAY);
            g2d.drawString("No space to display chart", startX + 10, startY + 20);
            return;
        }
        
        // Draw axes
        g2d.setColor(Color.BLACK);
        g2d.drawLine(startX, startY + height, startX + width, startY + height); // X-axis
        g2d.drawLine(startX, startY, startX, startY + height); // Y-axis
        
        // Find max income for scaling
        double maxIncome = monthlyIncomeData.values().stream().mapToDouble(Double::doubleValue).max().orElse(1.0);
        if (maxIncome == 0) maxIncome = 1000; // Set minimum scale
        
        List<String> months = new ArrayList<>(monthlyIncomeData.keySet());
        int pointWidth = width / 12; // 12 months
        
        // Draw income line
        g2d.setColor(Color.BLUE);
        g2d.setStroke(new java.awt.BasicStroke(2));
        
        for (int i = 0; i < months.size(); i++) {
            String monthKey = months.get(i);
            double income = monthlyIncomeData.get(monthKey);
            
            int pointX = startX + (i * pointWidth) + pointWidth/2;
            int pointY = startY + height - (int)((income / maxIncome) * height);
            
            // Draw point
            g2d.fillOval(pointX - 4, pointY - 4, 8, 8);
            
            // Draw line to next point
            if (i < months.size() - 1) {
                String nextMonthKey = months.get(i + 1);
                double nextIncome = monthlyIncomeData.get(nextMonthKey);
                int nextPointX = startX + ((i + 1) * pointWidth) + pointWidth/2;
                int nextPointY = startY + height - (int)((nextIncome / maxIncome) * height);
                g2d.drawLine(pointX, pointY, nextPointX, nextPointY);
            }
            
            // Draw month label
            g2d.setColor(Color.BLACK);
            int monthIndex = Integer.parseInt(monthKey) - 1;
            g2d.drawString(MONTH_NAMES[monthIndex], pointX - 15, startY + height + 20);
            
            // Draw value
            if (income > 0) {
                g2d.drawString(String.format("₱%.0f", income), pointX - 25, pointY - 10);
            }
            g2d.setColor(Color.BLUE);
        }
        
        // Draw Y-axis labels
        g2d.setColor(Color.BLACK);
        for (int i = 0; i <= 5; i++) {
            int y = startY + height - (i * height / 5);
            double value = (maxIncome * i) / 5;
            g2d.drawString(String.format("₱%.0f", value), 5, y + 5);
            g2d.drawLine(startX - 5, y, startX, y);
        }
    }

    // Draw customer bar chart
    private void drawCustomerChart(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        int width = customerChartPanel.getWidth() - 80;
        int height = customerChartPanel.getHeight() - 80;
        int startX = 40;
        int startY = 40;
        
        if (width <= 0 || height <= 0) {
            g2d.setColor(Color.GRAY);
            g2d.drawString("No space to display chart", startX + 10, startY + 20);
            return;
        }
        
        // Draw axes
        g2d.setColor(Color.BLACK);
        g2d.drawLine(startX, startY + height, startX + width, startY + height); // X-axis
        g2d.drawLine(startX, startY, startX, startY + height); // Y-axis
        
        // Find max customers for scaling
        int maxCustomers = monthlyCustomerData.values().stream().mapToInt(Integer::intValue).max().orElse(1);
        if (maxCustomers == 0) maxCustomers = 10; // Set minimum scale
        
        List<String> months = new ArrayList<>(monthlyCustomerData.keySet());
        int barWidth = (width / 12) - 10; // 12 months with spacing
        
        // Draw customer bars
        for (int i = 0; i < months.size(); i++) {
            String monthKey = months.get(i);
            int customers = monthlyCustomerData.get(monthKey);
            
            int barX = startX + (i * (barWidth + 10)) + 5;
            int barHeight = (int)((double)customers / maxCustomers * height);
            int barY = startY + height - barHeight;
            
            // Draw bar
            g2d.setColor(Color.GREEN);
            g2d.fillRect(barX, barY, barWidth, barHeight);
            
            // Draw border
            g2d.setColor(Color.DARK_GRAY);
            g2d.drawRect(barX, barY, barWidth, barHeight);
            
            // Draw value on top of bar
            g2d.setColor(Color.BLACK);
            if (customers > 0) {
                g2d.drawString(String.valueOf(customers), barX + barWidth/2 - 5, barY - 5);
            }
            
            // Draw month label
            int monthIndex = Integer.parseInt(monthKey) - 1;
            g2d.drawString(MONTH_NAMES[monthIndex], barX + barWidth/2 - 15, startY + height + 20);
        }
        
        // Draw Y-axis labels
        g2d.setColor(Color.BLACK);
        for (int i = 0; i <= 5; i++) {
            int y = startY + height - (i * height / 5);
            int value = (maxCustomers * i) / 5;
            g2d.drawString(String.valueOf(value), 5, y + 5);
            g2d.drawLine(startX - 5, y, startX, y);
        }
    }

    // Start auto-refresh timer (refresh every 30 seconds)
    private void startAutoRefresh() {
        refreshTimer = new Timer();
        refreshTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                javax.swing.SwingUtilities.invokeLater(() -> {
                    refreshStatistics();
                });
            }
        }, 30000, 30000); // 30 seconds interval
    }

    // Refresh all statistics and charts
    public void refreshStatistics() {
        initializeStatistics();
        updateCalendarDisplay(); // Refresh calendar to show new data
        if (incomeChartPanel != null) incomeChartPanel.repaint();
        if (customerChartPanel != null) customerChartPanel.repaint();
    }

    // Stop auto-refresh when window is closed
    @Override
    public void dispose() {
        if (refreshTimer != null) {
            refreshTimer.cancel();
        }
        super.dispose();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        kGradientPanel1 = new keeptoo.KGradientPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        kGradientPanel2 = new keeptoo.KGradientPanel();
        jLabel2 = new javax.swing.JLabel();
        kGradientPanel5 = new keeptoo.KGradientPanel();
        jLabel4 = new javax.swing.JLabel();
        kGradientPanel6 = new keeptoo.KGradientPanel();
        jLabel5 = new javax.swing.JLabel();
        kGradientPanel8 = new keeptoo.KGradientPanel();
        jLabel7 = new javax.swing.JLabel();
        kGradientPanel9 = new keeptoo.KGradientPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        kGradientPanel7 = new keeptoo.KGradientPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        kGradientPanel3 = new keeptoo.KGradientPanel();
        jPanel1 = new javax.swing.JPanel();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(100, 0), new java.awt.Dimension(100, 0), new java.awt.Dimension(100, 32767));
        kGradientPanel16 = new keeptoo.KGradientPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        kGradientPanel17 = new keeptoo.KGradientPanel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        kGradientPanel19 = new keeptoo.KGradientPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        kGradientPanel20 = new keeptoo.KGradientPanel();
        jLabel26 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Bakery Shop Management");
        setSize(new java.awt.Dimension(1900, 1030));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));
        jPanel2.setPreferredSize(new java.awt.Dimension(1900, 1030));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        kGradientPanel1.setkEndColor(new java.awt.Color(0, 0, 102));
        kGradientPanel1.setkGradientFocus(800);
        kGradientPanel1.setkStartColor(new java.awt.Color(51, 0, 51));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Bakery Shop Management");
        kGradientPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, 230, 30));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("____________________________________________");
        kGradientPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 260, -1));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-bread-and-rye-100.png"))); // NOI18N
        kGradientPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, -1, 100));

        jPanel2.add(kGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 310, 180));

        kGradientPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        kGradientPanel2.setkEndColor(new java.awt.Color(51, 0, 51));
        kGradientPanel2.setkStartColor(new java.awt.Color(51, 0, 51));
        kGradientPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-customer-25.png"))); // NOI18N
        jLabel2.setText("WELCOME | Admin");
        kGradientPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 200, 50));

        kGradientPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        kGradientPanel5.setkEndColor(new java.awt.Color(51, 51, 51));
        kGradientPanel5.setkGradientFocus(800);
        kGradientPanel5.setkStartColor(new java.awt.Color(51, 0, 51));
        kGradientPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-dashboard-25.png"))); // NOI18N
        jLabel4.setText("Dashboard");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel4MouseExited(evt);
            }
        });
        kGradientPanel5.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 5, 290, 50));

        kGradientPanel2.add(kGradientPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 290, 60));

        kGradientPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        kGradientPanel6.setkEndColor(new java.awt.Color(51, 51, 51));
        kGradientPanel6.setkGradientFocus(800);
        kGradientPanel6.setkStartColor(new java.awt.Color(51, 0, 51));
        kGradientPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-inventory-25_1.png"))); // NOI18N
        jLabel5.setText("Inventory");
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel5MouseExited(evt);
            }
        });
        kGradientPanel6.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 5, 290, 50));

        kGradientPanel2.add(kGradientPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 290, 60));

        kGradientPanel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        kGradientPanel8.setkEndColor(new java.awt.Color(51, 51, 51));
        kGradientPanel8.setkGradientFocus(800);
        kGradientPanel8.setkStartColor(new java.awt.Color(51, 0, 51));
        kGradientPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-history-25.png"))); // NOI18N
        jLabel7.setText("Order History");
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel7MouseExited(evt);
            }
        });
        kGradientPanel8.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 290, 60));

        kGradientPanel2.add(kGradientPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 290, 60));

        kGradientPanel9.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        kGradientPanel9.setkEndColor(new java.awt.Color(51, 51, 51));
        kGradientPanel9.setkGradientFocus(800);
        kGradientPanel9.setkStartColor(new java.awt.Color(51, 0, 51));
        kGradientPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-logout-25.png"))); // NOI18N
        jLabel8.setText("Logout");
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel8MouseExited(evt);
            }
        });
        kGradientPanel9.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 5, 290, 50));

        kGradientPanel2.add(kGradientPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, 290, 60));

        jPanel6.setBackground(new java.awt.Color(51, 51, 51));
        jPanel6.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(204, 204, 204)));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("BY: CALUAG & GROSPE");
        jPanel6.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        kGradientPanel2.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 570, 320, 50));

        kGradientPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        kGradientPanel7.setkEndColor(new java.awt.Color(51, 51, 51));
        kGradientPanel7.setkGradientFocus(800);
        kGradientPanel7.setkStartColor(new java.awt.Color(51, 0, 51));
        kGradientPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-menu-25.png"))); // NOI18N
        jLabel6.setText("Menu");
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel6MouseExited(evt);
            }
        });
        kGradientPanel7.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(9, 5, 280, 50));

        kGradientPanel2.add(kGradientPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, 290, 60));

        jLabel17.setFont(new java.awt.Font("Showcard Gothic", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("________________________________________");
        kGradientPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 340, -1));

        jPanel2.add(kGradientPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 180, 320, 630));

        kGradientPanel3.setkEndColor(new java.awt.Color(102, 0, 0));
        kGradientPanel3.setkGradientFocus(1000);
        kGradientPanel3.setkStartColor(new java.awt.Color(51, 0, 51));
        kGradientPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(filler1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 240, 380, -1));

        kGradientPanel16.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        kGradientPanel16.setkEndColor(new java.awt.Color(51, 0, 51));
        kGradientPanel16.setkGradientFocus(800);
        kGradientPanel16.setkStartColor(new java.awt.Color(51, 0, 51));
        kGradientPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("jLabel11");
        kGradientPanel16.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 20, -1, -1));

        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Total Income");
        kGradientPanel16.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 210, -1, -1));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/money-bag.png"))); // NOI18N
        kGradientPanel16.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));

        jPanel1.add(kGradientPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 10, 280, 240));

        kGradientPanel17.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        kGradientPanel17.setkEndColor(new java.awt.Color(51, 0, 51));
        kGradientPanel17.setkGradientFocus(800);
        kGradientPanel17.setkStartColor(new java.awt.Color(51, 0, 51));
        kGradientPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Number of Customer");
        kGradientPanel17.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, -1, -1));

        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("jLabel11");
        kGradientPanel17.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, -1, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/people.png"))); // NOI18N
        kGradientPanel17.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jPanel1.add(kGradientPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 280, 240));

        kGradientPanel19.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        kGradientPanel19.setkEndColor(new java.awt.Color(51, 0, 51));
        kGradientPanel19.setkGradientFocus(800);
        kGradientPanel19.setkStartColor(new java.awt.Color(51, 0, 51));
        kGradientPanel19.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Today's Income");
        kGradientPanel19.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 210, -1, -1));

        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("jLabel11");
        kGradientPanel19.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 20, -1, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/dollar.png"))); // NOI18N
        kGradientPanel19.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));

        jPanel1.add(kGradientPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 290, 240));

        kGradientPanel20.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        kGradientPanel20.setkEndColor(new java.awt.Color(51, 0, 51));
        kGradientPanel20.setkGradientFocus(800);
        kGradientPanel20.setkStartColor(new java.awt.Color(51, 0, 51));
        kGradientPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("jLabel11");
        kGradientPanel20.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 20, -1, -1));

        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Monthly Income");
        kGradientPanel20.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 210, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/profits.png"))); // NOI18N
        kGradientPanel20.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jPanel1.add(kGradientPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 10, 290, 240));

        kGradientPanel3.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 1210, 260));
        jPanel1.getAccessibleContext().setAccessibleDescription("");

        jPanel4.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        kGradientPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 330, 600, 450));

        jPanel5.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        kGradientPanel3.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 600, 450));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-dashboard-25.png"))); // NOI18N
        jLabel18.setText("Dashboard");
        jLabel18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel18MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel18MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel18MouseExited(evt);
            }
        });
        kGradientPanel3.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 150, 50));

        jPanel2.add(kGradientPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 0, 1240, 790));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1900, 1030));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        int option = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to logout?", 
            "Confirm Logout", 
            JOptionPane.YES_NO_OPTION);
        
        if (option == JOptionPane.YES_OPTION) {
            this.dispose();
            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {
                    new login().setVisible(true);
                }
            });
        }
    
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
       // Close all other windows and refresh dashboard
        java.awt.Window[] windows = java.awt.Window.getWindows();
        
        for (java.awt.Window window : windows) {
            if (window != this && window instanceof javax.swing.JFrame) {
                window.dispose();
            }
        }
        
        // Reset to today's date and refresh
        selectedCalendar = Calendar.getInstance();
        monthComboBox.setSelectedIndex(selectedCalendar.get(Calendar.MONTH));
        yearComboBox.setSelectedItem(selectedCalendar.get(Calendar.YEAR));
        updateCalendarDisplay();
        refreshStatistics();
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
           if (invenWindow == null || !invenWindow.isDisplayable()) {
            invenWindow = new inventory();
            try {
                Point panelLocation = kGradientPanel3.getLocationOnScreen();
                invenWindow.setLocation(panelLocation);
            } catch (IllegalComponentStateException ex) {
                System.out.println("Panel not visible: " + ex.getMessage());
            }
            invenWindow.setVisible(true);
        } else {
            invenWindow.toFront();
            invenWindow.requestFocus();
        }
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
            if (menuWindow == null || !menuWindow.isDisplayable()) {
            menuWindow = new menu();
            try {
                Point panelLocation = kGradientPanel3.getLocationOnScreen();
                menuWindow.setLocation(panelLocation);
            } catch (IllegalComponentStateException ex) {
                System.out.println("Panel not visible: " + ex.getMessage());
            }
            menuWindow.setVisible(true);
        } else {
            menuWindow.toFront();
            menuWindow.requestFocus();
        }
    }//GEN-LAST:event_jLabel6MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
            if (cusWindow == null || !cusWindow.isDisplayable()) {
            cusWindow = new customer();
            try {
                Point panelLocation = kGradientPanel3.getLocationOnScreen();
                cusWindow.setLocation(panelLocation);
            } catch (IllegalComponentStateException ex) {
                System.out.println("Panel not visible: " + ex.getMessage());
            }
            cusWindow.setVisible(true);
        } else {
            cusWindow.toFront();
            cusWindow.requestFocus();
        }
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseEntered
        kGradientPanel5.setBackground(mouseEnterColor);
    }//GEN-LAST:event_jLabel4MouseEntered

    private void jLabel4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseExited
        kGradientPanel5.setBackground(mouseExitColor);
    }//GEN-LAST:event_jLabel4MouseExited

    private void jLabel5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseEntered
        kGradientPanel6.setBackground(mouseEnterColor);
    }//GEN-LAST:event_jLabel5MouseEntered

    private void jLabel5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseExited
        kGradientPanel6.setBackground(mouseExitColor);
    }//GEN-LAST:event_jLabel5MouseExited

    private void jLabel6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseEntered
        kGradientPanel7.setBackground(mouseEnterColor);
    }//GEN-LAST:event_jLabel6MouseEntered

    private void jLabel6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseExited
        kGradientPanel7.setBackground(mouseExitColor);
    }//GEN-LAST:event_jLabel6MouseExited

    private void jLabel7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseEntered
        kGradientPanel8.setBackground(mouseEnterColor);
    }//GEN-LAST:event_jLabel7MouseEntered

    private void jLabel7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseExited
        kGradientPanel8.setBackground(mouseExitColor);
    }//GEN-LAST:event_jLabel7MouseExited

    private void jLabel8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseEntered
        kGradientPanel9.setBackground(mouseEnterColor);
    }//GEN-LAST:event_jLabel8MouseEntered

    private void jLabel8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseExited
        kGradientPanel9.setBackground(mouseExitColor);
    }//GEN-LAST:event_jLabel8MouseExited

    private void jLabel18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel18MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel18MouseClicked

    private void jLabel18MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel18MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel18MouseEntered

    private void jLabel18MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel18MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel18MouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new dashboard().setVisible(true);
            }
        });

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new dashboard().setVisible(true);
            }
        });     
    }
    private Color mouseEnterColor = new Color (0,51,51);  // Cyan-ish
    private Color mouseExitColor = new Color(204, 204, 204); // Default

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.Box.Filler filler1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private keeptoo.KGradientPanel kGradientPanel1;
    private keeptoo.KGradientPanel kGradientPanel16;
    private keeptoo.KGradientPanel kGradientPanel17;
    private keeptoo.KGradientPanel kGradientPanel19;
    private keeptoo.KGradientPanel kGradientPanel2;
    private keeptoo.KGradientPanel kGradientPanel20;
    private keeptoo.KGradientPanel kGradientPanel3;
    private keeptoo.KGradientPanel kGradientPanel5;
    private keeptoo.KGradientPanel kGradientPanel6;
    private keeptoo.KGradientPanel kGradientPanel7;
    private keeptoo.KGradientPanel kGradientPanel8;
    private keeptoo.KGradientPanel kGradientPanel9;
    // End of variables declaration//GEN-END:variables
}
