/*
 * Enhanced menu.java with Receipt Integration
 */

import METHODS.CHECKING;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class menu extends javax.swing.JFrame {

    CHECKING CK = new CHECKING();
    Random random= new Random();
    private DefaultTableModel orderTableModel;
    private List<InventoryItem> inventoryItems;
    private double totalAmount = 0.0;
    
    private int selectedOrderRow = -1;

    
    
    
    // Inner class to hold inventory item data
    private class InventoryItem {
        String productId;
        String productName;
        int stock;
        double price;
        String imagePath;
        
        public InventoryItem(String productId, String productName, int stock, double price, String imagePath) {
            this.productId = productId;
            this.productName = productName;
            this.stock = stock;
            this.price = price;
            this.imagePath = imagePath;
        }
    }

    public menu() {
        initComponents();
        setupOrderTable();
        loadInventoryItems();
        displayProductsInPanels();
        setupTableClickListener();
        updateTotalDisplay();
        
        // Add key listener for automatic change calculation
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                calculateChange();
            }
        });
    }

    // Setup the order table
    private void setupOrderTable() {
        orderTableModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        String[] columns = {"Product Name", "Quantity", "Unit Price", "Total Price"};
        orderTableModel.setColumnIdentifiers(columns);
        jTable1.setModel(orderTableModel);
        
        // Set column widths
        jTable1.getColumnModel().getColumn(0).setPreferredWidth(150);
        jTable1.getColumnModel().getColumn(1).setPreferredWidth(80);
        jTable1.getColumnModel().getColumn(2).setPreferredWidth(100);
        jTable1.getColumnModel().getColumn(3).setPreferredWidth(100);
    }

    // Setup table click listener for order selection
    private void setupTableClickListener() {
        jTable1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                selectedOrderRow = jTable1.getSelectedRow();
            }
        });
    }

    // Load inventory items from database
    private void loadInventoryItems() {
        inventoryItems = new ArrayList<>();
        
        String query = "SELECT product_id, product_name, stock, price, image_path FROM inventory WHERE stock > 0 ORDER BY product_name LIMIT 9";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            
            if (conn == null) {
                JOptionPane.showMessageDialog(this, "Database connection failed!");
                return;
            }
            
            while (rs.next()) {
                InventoryItem item = new InventoryItem(
                    rs.getString("product_id"),
                    rs.getString("product_name"),
                    rs.getInt("stock"),
                    rs.getDouble("price"),
                    rs.getString("image_path")
                );
                inventoryItems.add(item);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading inventory: " + e.getMessage());
        }
    }

    // Display products in the 9 panels
    private void displayProductsInPanels() {
        // Arrays of components for easier management
        java.awt.Label[] productLabels = {label1, label2, label3, label4, label5, label6, label7, label8, label9};
        javax.swing.JLabel[] priceLabels = {jLabel1, jLabel3, jLabel5, jLabel7, jLabel9, jLabel11, jLabel13, jLabel15, jLabel17};
        javax.swing.JLabel[] imageLabels = {jLabel2, jLabel4, jLabel6, jLabel8, jLabel10, jLabel12, jLabel14, jLabel16, jLabel18};
        javax.swing.JSpinner[] spinners = {jSpinner1, jSpinner2, jSpinner3, jSpinner4, jSpinner5, jSpinner6, jSpinner7, jSpinner8, jSpinner9};

        // Clear all panels first
        for (int i = 0; i < 9; i++) {
            productLabels[i].setText("No Product");
            priceLabels[i].setText("₱0.00");
            imageLabels[i].setIcon(null);
            imageLabels[i].setText("No Image");
            spinners[i].setValue(0);
        }

        // Display available products
        for (int i = 0; i < Math.min(inventoryItems.size(), 9); i++) {
            InventoryItem item = inventoryItems.get(i);
            
            productLabels[i].setText(item.productName);
            priceLabels[i].setText(String.format("₱%.2f", item.price));
            displayProductImage(item.imagePath, imageLabels[i]);
            spinners[i].setValue(1);
        }
    }

    // Display product image in specified label
    private void displayProductImage(String imagePath, javax.swing.JLabel imageLabel) {
        try {
            if (imagePath == null || imagePath.isEmpty()) {
                imageLabel.setIcon(null);
                imageLabel.setText("No Image");
                return;
            }
            
            File imageFile = new File(imagePath);
            if (!imageFile.exists()) {
                imageLabel.setIcon(null);
                imageLabel.setText("Image Not Found");
                return;
            }
            
            ImageIcon originalIcon = new ImageIcon(imagePath);
            if (originalIcon.getIconWidth() <= 0) {
                imageLabel.setIcon(null);
                imageLabel.setText("Invalid Image");
                return;
            }
            
            // Scale image to fit label
            int labelWidth = 170;
            int labelHeight = 140;
            
            Image originalImage = originalIcon.getImage();
            Image scaledImage = originalImage.getScaledInstance(labelWidth, labelHeight, Image.SCALE_SMOOTH);
            
            imageLabel.setIcon(new ImageIcon(scaledImage));
            imageLabel.setText("");
            
        } catch (Exception e) {
            imageLabel.setIcon(null);
            imageLabel.setText("Error Loading Image");
        }
    }

    // Add product to order (generic method for all panels)
    private void addProductToOrder(int panelIndex) {
        if (panelIndex >= inventoryItems.size()) {
            JOptionPane.showMessageDialog(this, "No product available in this panel!");
            return;
        }

        InventoryItem item = inventoryItems.get(panelIndex);
        javax.swing.JSpinner[] spinners = {jSpinner1, jSpinner2, jSpinner3, jSpinner4, jSpinner5, jSpinner6, jSpinner7, jSpinner8, jSpinner9};
        
        int quantity = (Integer) spinners[panelIndex].getValue();
        
        if (quantity <= 0) {
            JOptionPane.showMessageDialog(this, "Please select a valid quantity!");
            return;
        }
        
        if (quantity > item.stock) {
            JOptionPane.showMessageDialog(this, 
                "Insufficient stock! Available: " + item.stock + " pieces");
            return;
        }

        // Check if item already exists in order
        boolean itemExists = false;
        for (int i = 0; i < orderTableModel.getRowCount(); i++) {
            if (orderTableModel.getValueAt(i, 0).toString().equals(item.productName)) {
                // Update existing item
                int existingQty = Integer.parseInt(orderTableModel.getValueAt(i, 1).toString());
                int newQty = existingQty + quantity;
                
                if (newQty > item.stock) {
                    JOptionPane.showMessageDialog(this, "Total quantity exceeds available stock!");
                    return;
                }
                
                double newTotal = newQty * item.price;
                orderTableModel.setValueAt(newQty, i, 1);
                orderTableModel.setValueAt(String.format("₱%.2f", newTotal), i, 3);
                itemExists = true;
                break;
            }
        }

        if (!itemExists) {
            // Add new item to order
            double totalPrice = quantity * item.price;
            Object[] orderRow = {
                item.productName,
                quantity,
                String.format("₱%.2f", item.price),
                String.format("₱%.2f", totalPrice)
            };
            orderTableModel.addRow(orderRow);
        }

        calculateTotal();
        spinners[panelIndex].setValue(1); // Reset spinner
        
        // Show confirmation
        JOptionPane.showMessageDialog(this, 
            quantity + "x " + item.productName + " added to order!",
            "Item Added", 
            JOptionPane.INFORMATION_MESSAGE);
    }

    // Calculate total amount
    private void calculateTotal() {
        totalAmount = 0.0;
        for (int i = 0; i < orderTableModel.getRowCount(); i++) {
            String totalStr = orderTableModel.getValueAt(i, 3).toString();
            totalStr = totalStr.replace("₱", "").replace(",", "");
            totalAmount += Double.parseDouble(totalStr);
        }
        updateTotalDisplay();
    }

    // Update total display
    private void updateTotalDisplay() {
        jLabel23.setText(String.format("₱%.2f", totalAmount));
        calculateChange();
    }

    // Calculate change
    private void calculateChange() {
        try {
            String amountText = jTextField1.getText().trim();
            if (!amountText.isEmpty() && !amountText.equals("jTextField1")) {
                double amountPaid = Double.parseDouble(amountText);
                double change = amountPaid - totalAmount;
                jLabel19.setText(String.format("₱%.2f", Math.max(0, change)));
            } else {
                jLabel19.setText("₱0.00");
            }
        } catch (NumberFormatException e) {
            jLabel19.setText("₱0.00");
        }
    }
    
   
    // Enhanced process payment with receipt generation
    private void processPayment() {
        if (orderTableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No items in order!");
            return;
        }

        try {
            String amountText = jTextField1.getText().trim();
            if (amountText.isEmpty() || amountText.equals("jTextField1")) {
                JOptionPane.showMessageDialog(this, "Please enter payment amount!");
                return;
            }

            double amountPaid = Double.parseDouble(amountText);
            if (amountPaid < totalAmount) {
                JOptionPane.showMessageDialog(this, "Insufficient payment amount!");
                return;
            }

            // Create order items list for receipt
            List<ReceiptWindow.OrderItem> orderItems = new ArrayList<>();
            for (int i = 0; i < orderTableModel.getRowCount(); i++) {
                String productName = orderTableModel.getValueAt(i, 0).toString();
                int quantity = Integer.parseInt(orderTableModel.getValueAt(i, 1).toString());
                String unitPriceStr = orderTableModel.getValueAt(i, 2).toString().replace("₱", "").replace(",", "");
                double unitPrice = Double.parseDouble(unitPriceStr);
                
                orderItems.add(new ReceiptWindow.OrderItem(productName, quantity, unitPrice));
            }

            // Update inventory and save transaction
            updateInventoryAfterSale();
            
            
            
            saveTransaction();

            // Show success message
            double change = amountPaid - totalAmount;
            JOptionPane.showMessageDialog(this, 
                "Payment successful!\nChange: ₱" + String.format("%.2f", change),
                "Payment Complete",
                JOptionPane.INFORMATION_MESSAGE);

            // Generate and show receipt
            ReceiptWindow.showReceipt(orderItems, amountPaid, transactionNumber);

            // Ask if user wants to clear order
            int clearOrder = JOptionPane.showConfirmDialog(this,
                "Do you want to clear the order for the next customer?",
                "Clear Order",
                JOptionPane.YES_NO_OPTION);
            
            if (clearOrder == JOptionPane.YES_OPTION) {
                clearOrder();
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid payment amount!");
        }
    }

    // Update inventory after sale
    private void updateInventoryAfterSale() {
        String query = "UPDATE inventory SET stock = stock - ? WHERE product_name = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            if (conn == null) return;
            
            for (int i = 0; i < orderTableModel.getRowCount(); i++) {
                String productName = orderTableModel.getValueAt(i, 0).toString();
                int quantity = Integer.parseInt(orderTableModel.getValueAt(i, 1).toString());
                
                pstmt.setInt(1, quantity);
                pstmt.setString(2, productName);
                pstmt.executeUpdate();
            }
            
            // Refresh inventory display
            loadInventoryItems();
            displayProductsInPanels();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error updating inventory: " + e.getMessage());
        }
    }

    
    
    
    public boolean check_invoice(int invoice){
        boolean check_invoice=false;
        
        int id = invoice;
        
         try (Connection conn = DatabaseConnection.getConnection()) {
        String sql = "SELECT * FROM `transactions` WHERE `transaction_number`=?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, id); 

        ResultSet rs = stmt.executeQuery();

        if (rs.next()) { 
            check_invoice=true;
        }

    } catch (Exception ex) {
        ex.printStackTrace(); 
    } 
        
        return check_invoice;
    }
     
     
    
    
    // Save transaction to database 
    
    private int invoice_number=random.nextInt(900000); 
    private int transactionNumber = invoice_number;
     
    private void saveTransaction() { 
        
        if(check_invoice(transactionNumber)){
            invoice_number = random.nextInt(900000); 
            save_transaction(transactionNumber);
        }else{
            save_transaction(transactionNumber);
        }
        
       
    }
    
    
    void save_transaction(int transactionNumber){
         String query = "INSERT INTO transactions (transaction_number, product_name, quantity, unit_price, total_price) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            if (conn == null) return;
            
            for (int i = 0; i < orderTableModel.getRowCount(); i++) {
                String productName = orderTableModel.getValueAt(i, 0).toString();
                int quantity = Integer.parseInt(orderTableModel.getValueAt(i, 1).toString());
                String unitPriceStr = orderTableModel.getValueAt(i, 2).toString().replace("₱", "").replace(",", "");
                String totalPriceStr = orderTableModel.getValueAt(i, 3).toString().replace("₱", "").replace(",", "");
                
                
                pstmt.setInt(1, transactionNumber);
                pstmt.setString(2, productName);
                pstmt.setInt(3, quantity);
                pstmt.setDouble(4, Double.parseDouble(unitPriceStr));
                pstmt.setDouble(5, Double.parseDouble(totalPriceStr));
                pstmt.executeUpdate();
            }
            
            
        } catch (SQLException e) {
            System.err.println("Error saving transaction: " + e.getMessage());
        }
    }
    
    
    

    // Remove selected item from order
    private void removeSelectedItem() {
        if (selectedOrderRow >= 0 && selectedOrderRow < orderTableModel.getRowCount()) {
            String productName = orderTableModel.getValueAt(selectedOrderRow, 0).toString();
            int confirm = JOptionPane.showConfirmDialog(this,
                "Remove " + productName + " from order?",
                "Confirm Remove",
                JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                orderTableModel.removeRow(selectedOrderRow);
                calculateTotal();
                selectedOrderRow = -1;
                jTable1.clearSelection();
                JOptionPane.showMessageDialog(this, "Item removed from order!");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an item to remove!");
        }
    }

    // Clear entire order
    private void clearOrder() {
        if (orderTableModel.getRowCount() > 0) {
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to clear the entire order?",
                "Clear Order",
                JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                orderTableModel.setRowCount(0);
                totalAmount = 0.0;
                jTextField1.setText("");
                updateTotalDisplay();
                selectedOrderRow = -1;
                JOptionPane.showMessageDialog(this, "Order cleared!");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Order is already empty!");
        }
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        kGradientPanel1 = new keeptoo.KGradientPanel();
        jPanel58 = new javax.swing.JPanel();
        label7 = new java.awt.Label();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jSpinner7 = new javax.swing.JSpinner();
        jButton9 = new javax.swing.JButton();
        jPanel60 = new javax.swing.JPanel();
        label9 = new java.awt.Label();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jSpinner9 = new javax.swing.JSpinner();
        jButton11 = new javax.swing.JButton();
        jPanel59 = new javax.swing.JPanel();
        label8 = new java.awt.Label();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jSpinner8 = new javax.swing.JSpinner();
        jButton10 = new javax.swing.JButton();
        jPanel55 = new javax.swing.JPanel();
        label4 = new java.awt.Label();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jSpinner4 = new javax.swing.JSpinner();
        jButton6 = new javax.swing.JButton();
        jPanel57 = new javax.swing.JPanel();
        label6 = new java.awt.Label();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jSpinner6 = new javax.swing.JSpinner();
        jButton8 = new javax.swing.JButton();
        jPanel56 = new javax.swing.JPanel();
        label5 = new java.awt.Label();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jSpinner5 = new javax.swing.JSpinner();
        jButton7 = new javax.swing.JButton();
        jPanel53 = new javax.swing.JPanel();
        label2 = new java.awt.Label();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jSpinner2 = new javax.swing.JSpinner();
        jButton4 = new javax.swing.JButton();
        jPanel45 = new javax.swing.JPanel();
        label1 = new java.awt.Label();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jSpinner1 = new javax.swing.JSpinner();
        jButton3 = new javax.swing.JButton();
        jPanel54 = new javax.swing.JPanel();
        label3 = new java.awt.Label();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jSpinner3 = new javax.swing.JSpinner();
        jButton5 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel1.setkEndColor(new java.awt.Color(102, 0, 0));
        kGradientPanel1.setkGradientFocus(1500);
        kGradientPanel1.setkStartColor(new java.awt.Color(51, 0, 51));

        jPanel58.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel58.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label7.setText("label1");
        jPanel58.add(label7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel13.setText("jLabel1");
        jPanel58.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, -1, -1));

        jLabel14.setText("jLabel2");
        jPanel58.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 170, 140));
        jPanel58.add(jSpinner7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 100, -1));

        jButton9.setBackground(new java.awt.Color(0, 102, 102));
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setText("Add");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel58.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 210, 80, -1));

        jPanel60.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel60.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label9.setText("label1");
        jPanel60.add(label9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel17.setText("jLabel1");
        jPanel60.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, -1, -1));

        jLabel18.setText("jLabel2");
        jPanel60.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 170, 140));
        jPanel60.add(jSpinner9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 100, -1));

        jButton11.setBackground(new java.awt.Color(0, 102, 102));
        jButton11.setForeground(new java.awt.Color(255, 255, 255));
        jButton11.setText("Add");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel60.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(132, 210, 80, -1));

        jPanel59.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel59.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label8.setText("label1");
        jPanel59.add(label8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel15.setText("jLabel1");
        jPanel59.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, -1, -1));

        jLabel16.setText("jLabel2");
        jPanel59.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 170, 140));
        jPanel59.add(jSpinner8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 100, -1));

        jButton10.setBackground(new java.awt.Color(0, 102, 102));
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setText("Add");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel59.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(132, 210, 80, -1));

        jPanel55.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel55.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label4.setText("label1");
        jPanel55.add(label4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel7.setText("jLabel1");
        jPanel55.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, -1, -1));

        jLabel8.setText("jLabel2");
        jPanel55.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 170, 140));
        jPanel55.add(jSpinner4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 100, -1));

        jButton6.setBackground(new java.awt.Color(0, 102, 102));
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Add");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel55.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(132, 210, 80, -1));

        jPanel57.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel57.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label6.setText("label1");
        jPanel57.add(label6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel11.setText("jLabel1");
        jPanel57.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, -1, -1));

        jLabel12.setText("jLabel2");
        jPanel57.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 170, 140));
        jPanel57.add(jSpinner6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 100, -1));

        jButton8.setBackground(new java.awt.Color(0, 102, 102));
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("Add");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel57.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(132, 210, 80, -1));

        jPanel56.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel56.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label5.setText("label1");
        jPanel56.add(label5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel9.setText("jLabel1");
        jPanel56.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, -1, -1));

        jLabel10.setText("jLabel2");
        jPanel56.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 170, 140));
        jPanel56.add(jSpinner5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 100, -1));

        jButton7.setBackground(new java.awt.Color(0, 102, 102));
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("Add");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(132, 210, 80, -1));

        jPanel53.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel53.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label2.setText("label1");
        jPanel53.add(label2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel3.setText("jLabel1");
        jPanel53.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, -1, -1));

        jLabel4.setText("jLabel2");
        jPanel53.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 170, 140));
        jPanel53.add(jSpinner2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 100, -1));

        jButton4.setBackground(new java.awt.Color(0, 102, 102));
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Add");
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4MouseClicked(evt);
            }
        });
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel53.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(132, 210, 80, -1));

        jPanel45.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel45.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label1.setText("label1");
        jPanel45.add(label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel1.setText("jLabel1");
        jPanel45.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, -1, -1));

        jLabel2.setText("jLabel2");
        jPanel45.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 170, 140));
        jPanel45.add(jSpinner1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 100, -1));

        jButton3.setBackground(new java.awt.Color(0, 102, 102));
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Add");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel45.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(132, 210, 80, -1));

        jPanel54.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel54.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label3.setText("label1");
        jPanel54.add(label3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel5.setText("jLabel1");
        jPanel54.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, -1, -1));

        jLabel6.setText("jLabel2");
        jPanel54.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 170, 140));
        jPanel54.add(jSpinner3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 100, -1));

        jButton5.setBackground(new java.awt.Color(0, 102, 102));
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Add");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel54.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(132, 210, 80, -1));

        javax.swing.GroupLayout kGradientPanel1Layout = new javax.swing.GroupLayout(kGradientPanel1);
        kGradientPanel1.setLayout(kGradientPanel1Layout);
        kGradientPanel1Layout.setHorizontalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel59, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel60, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel53, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel56, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel57, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel54, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel55, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel58, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel45, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
        );
        kGradientPanel1Layout.setVerticalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel53, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel45, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel54, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel55, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel57, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel56, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel59, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel60, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel58, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel1.add(kGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, 0, 790, 790));

        jPanel7.setBackground(new java.awt.Color(204, 204, 204));
        jPanel7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setBackground(new java.awt.Color(255, 153, 153));

        jTable1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Product Name", "Quantity", "Price"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jPanel7.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 440, -1));

        jLabel19.setText("jLabel19");
        jPanel7.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 540, -1, 20));

        jLabel20.setText("Total:");
        jPanel7.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, -1, 20));

        jLabel21.setText("Amout:");
        jPanel7.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 500, -1, 20));

        jLabel22.setText("Change:");
        jPanel7.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 540, -1, 20));

        jLabel23.setText("jLabel19");
        jPanel7.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 460, -1, 20));

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel7.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 500, 150, -1));

        jButton13.setBackground(new java.awt.Color(0, 102, 102));
        jButton13.setForeground(new java.awt.Color(255, 255, 255));
        jButton13.setText("Pay");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 590, 440, 50));

        jButton14.setBackground(new java.awt.Color(0, 102, 102));
        jButton14.setForeground(new java.awt.Color(255, 255, 255));
        jButton14.setText("Remove");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 650, 440, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 754, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 477, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        addProductToOrder(0); // Panel 1
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        addProductToOrder(1); // Panel 2
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        addProductToOrder(2); // Panel 3
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        addProductToOrder(3); // Panel 4
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        addProductToOrder(4); // Panel 5
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        addProductToOrder(5); // Panel 6
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        addProductToOrder(6); // Panel 7
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        addProductToOrder(7); // Panel 8
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        addProductToOrder(8); // Panel 9
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        processPayment(); // Pay button
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        removeSelectedItem(); // Remove button
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseClicked
        calculateChange();
    }//GEN-LAST:event_jButton4MouseClicked

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel55;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel59;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JSpinner jSpinner2;
    private javax.swing.JSpinner jSpinner3;
    private javax.swing.JSpinner jSpinner4;
    private javax.swing.JSpinner jSpinner5;
    private javax.swing.JSpinner jSpinner6;
    private javax.swing.JSpinner jSpinner7;
    private javax.swing.JSpinner jSpinner8;
    private javax.swing.JSpinner jSpinner9;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private keeptoo.KGradientPanel kGradientPanel1;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private java.awt.Label label3;
    private java.awt.Label label4;
    private java.awt.Label label5;
    private java.awt.Label label6;
    private java.awt.Label label7;
    private java.awt.Label label8;
    private java.awt.Label label9;
    // End of variables declaration//GEN-END:variables
}
